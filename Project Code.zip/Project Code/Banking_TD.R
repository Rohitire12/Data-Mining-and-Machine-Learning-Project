# Banking dataset - Naive bayes and SVM model applied

library(ggplot2)
library(dplyr) 
library(readr)
library(skimr)
library(DataExplorer)
library(tidyverse)

# Setting the current working directory
setwd("~/Desktop")

# Loading the dataset
df <- read.table("bank-additional-full.csv",
                      sep = ';' ,
                      header = TRUE,
                      stringsAsFactors = TRUE)
head(df,10)

# Checking the dimension of dataset
str(df)

# Checking the NA Values
sum(is.na(df))
sapply(df, function(x) sum(is.na(x)))
df <- na.omit(df)

# Checking columns visualizations for loan vriable with respect to age and job
p <- ggplot(df, aes(x=job, y=age, fill= loan))  
p+geom_boxplot()

# Checking columns visualizations for loan vriable with respect to age and contact type
p <- ggplot(df, aes(x=contact, y=age, fill= loan))  
p+geom_boxplot()

# Checking columns visualizations for loan vriable with respect to age and term deposit(Dependent variable = Y)
p <-ggplot(df, aes(y,age,fill="blue"))
p +geom_boxplot(outlier.colour="green",fill="yellow",color="blue")

# Checking the distribution of customer age in datset.
hist(df$age,col= 'light blue')
hist(df$cons.price.idx,col= 'light blue')


# Changing the variable level
df$loan = factor(df$loan,
                 levels = c('no', 'yes','unknown'),
                 labels = c(0, 1, 2))
#Changing the variable level
df$y = factor(df$y,
              levels = c('no', 'yes'),
              labels = c(0, 1))

summary(df$contact)

df$poutcome = factor(df$poutcome,
                 levels = c('failure', 'nonexistent','success'),
                 labels = c(0, 1, 2))

df$job = factor(df$job,
                     levels = c('admin.', 'blue-collar','entrepreneur', 'housemaid', 'management', 'retired', 'self-employed', 'services', 'student', 'technician', 'unemployed', 'unknown'),
                     labels = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11))

df$marital = factor(df$marital,
                     levels = c('divorced', 'married','single', 'unknown'),
                     labels = c(0, 1, 2, 3))

df$education = factor(df$education,
                    levels = c('basic.4y', 'basic.6y','basic.9y', 'high.school', 'illiterate', 'professional.course', 'university.degree', 'unknown'),
                    labels = c(0, 1, 2, 3, 4, 5, 6, 7))

df$housing = factor(df$housing,
                 levels = c('no', 'yes','unknown'),
                 labels = c(0, 1, 2))

df$contact = factor(df$contact,
                    levels = c('cellular', 'telephone'),
                    labels = c(0, 1))

#Deleting unwanted columns
drops <- c("default","month","day_of_week")
df = df[ , !(names(df) %in% drops)]

# install.packages('caTools')
library(caTools)
set.seed(123)
split = sample.split(df$y, SplitRatio = 0.75)
training_set = subset(df, split == TRUE)
test_set = subset(df, split == FALSE)

#############################  Naive bayes ################## 
# install.packages('e1071')
library(e1071)
classifier = naiveBayes(x = training_set,
                        y = training_set$y, laplace = 2)
y_pred = predict(classifier, newdata = test_set)
library(gmodels)
CrossTable(y_pred, test_set$y, prop.chisq = FALSE, prop.t = FALSE, dnn = c('predicted', 'actual'))


#ROC for naive bayes
#install.packages("ROCR")
library(ROCR)
sapply(c(is.vector, is.matrix, is.list, is.data.frame), do.call, list(test_set$y))
prediction = prediction(as.numeric(y_pred), as.numeric(test_set$y))
perf = performance(prediction, "tpr", "fpr")

plot(perf, main = "ROC curve", col = "blue", lwd = 3)
abline(a = 0, b = 1, lwd = 2, lty = 2)

perf.auc = performance(prediction, measure = "auc")  
str(perf.auc)               # Gives accuracy ..


####################### SVM  Model #######################


classifier1 = svm(y~., data = training_set, kernel = "sigmoid")
y_pred1 = predict(classifier1, newdata = test_set)
CrossTable(y_pred1, test_set$y, prop.chisq = FALSE, prop.t = FALSE, dnn = c('predicted', 'actual'))

sapply(c(is.vector, is.matrix, is.list, is.data.frame), do.call, list(test_set$y))
prediction2 = prediction(as.numeric(y_pred1), as.numeric(test_set$y))
perf = performance(prediction2, "tpr", "fpr")

plot(perf, main = "ROC curve", col = "blue", lwd = 3)
abline(a = 0, b = 1, lwd = 2, lty = 2)

perf.auc = performance(prediction2, measure = "auc")

str(perf.auc)     # Gives accuracy ..~$







