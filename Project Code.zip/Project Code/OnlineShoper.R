#########################    Logistic Regression  & Decision Tree model applied####################
# setting working Directory
setwd("~/Desktop")
# Importing the dataset
# install.packages('readr')
# install.packages('dplyr')
library(readr)
library(dplyr)

ShopperData <- read_csv("online_shoppers_intention.csv")
str(ShopperData)

# Checking the NA Values
sum(is.na(ShopperData))
sapply(ShopperData, function(x) sum(is.na(x)))
ShopperData <- na.omit(ShopperData)

# Encoding the target feature as factor
ShopperData$Revenue <- as.factor(ShopperData$Revenue) 

# Encoding the other variable as factor
ShopperData$Weekend <- as.factor(ShopperData$Weekend) 
ShopperData$VisitorType <- as.factor(ShopperData$VisitorType)
ShopperData$TrafficType <- as.factor(ShopperData$TrafficType)
ShopperData$OperatingSystems <- as.factor(ShopperData$OperatingSystems)
ShopperData$Browser <- as.factor(ShopperData$Browser)
ShopperData$Region <- as.factor(ShopperData$Region)
ShopperData$Month <- as.factor(ShopperData$Month) 
str(ShopperData)

# Histoogram for some independent variable
library(ggplot2)
par(mfcol=c(1,1))
plot(ShopperData$Revenue,main="Revenue")
plot(ShopperData$VisitorType,main="VisitorType")
plot(ShopperData$TrafficType,main="TrafficType")
plot(ShopperData$Month,main="Month")

##Too many levels in browser variable
#so i have applied recode and final variable level to 1,2
summary(ShopperData$Browser)
##ShopperData$Browser<-recode(ShopperData$Browser,c('3','4','5','6','7','8','9','10','11','12','13') = '1')

ShopperData$Browser = recode(ShopperData$Browser, '3' = '1')
# if getting error please quit R and try again
ShopperData$Browser = recode(ShopperData$Browser, '4' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '5' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '6' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '7' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '8' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '9' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '10' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '11' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '12' = '1')
ShopperData$Browser = recode(ShopperData$Browser, '13' = '1')

##Too many levels in Traffic Type variable
#so i have applied recode and decrease the level to 1,2,3,4
summary(ShopperData$TrafficType)
ShopperData$TrafficType = recode(ShopperData$TrafficType, '4' = '3')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '6' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '7' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '8' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '9' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '10' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '11' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '12' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '13' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '14' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '15' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '16' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '17' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '18' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '19' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '20' = '5')
ShopperData$TrafficType = recode(ShopperData$TrafficType, '5' = '4')
summary(ShopperData)

# checking the non - linearity and transformation variable 
cor(ShopperData[,c(1,2,3,4,5,6,7,8,9,10)])
#scatterplotMatrix(ShopperData[,c(6,7,8,9,10)],col="lightblue")


# Splitting the dataset into the Training set and Test set
# library(caTools)
library(caret)
set.seed(1996)
split <- createDataPartition(ShopperData$Revenue, p=0.75, list = FALSE, times = 1)
training_set <- ShopperData[split,]  # split is TRUE in train model
test_set <- ShopperData[-split,]  # split is FALSE in train model

#Checking TRUE and FALSE proportions of train and test model.
prop.table(table(training_set$Revenue)) 
prop.table(table(test_set$Revenue))

# Feature Scaling of test and train model
preprocess <- preProcess(training_set, method = c("center", "scale"))
training_setprocessed <- predict(preprocess, training_set)
test_setprocessed <- predict(preprocess, test_set)

#########################    Logistic Regression   ####################
# Fitting Logistic Regression to the Training set
set.seed(1996)
classifier <- glm(Revenue ~.,data = training_setprocessed, family = binomial)
summary(classifier)

#checking the Multicolinearity using the variance inflation factor
# install.packages('car')
library(car)
vif(classifier)

# Applying Prediction 
classifier_preds <- predict(classifier, type="response", test_setprocessed)
classifier_preds <- ifelse(classifier_preds > 0.5, "TRUE", "FALSE")

# checking Accuracy of the model
Accuracy = mean(classifier_preds == test_setprocessed$Revenue)
cat("\nAccuracy of the Model\n")
Accuracy

# Confusion Matrix
cm = table(classifier_preds, test_setprocessed$Revenue)
cat("\nEvaluation of the Model\n")
cm



#########################   Decision Tree   #######################
###
# install.packages('rpart')
# install.packages('rpart.plot')
library(rpart)
library(rpart.plot)

# Applying the Decision model using the previously used train and test model
set.seed(1)
Decision_Tree <- rpart(Revenue ~ ., data = training_setprocessed, method = "class")
options(repr.plot.width = 10, repr.plot.height = 10)
rpart.plot(Decision_Tree, box.palette = "RdYlGn", shadow.col = "darkgray")
data.frame(Decision_Tree$variable.importance)

#prediction and evaluation of the model

prediction <- predict(Decision_Tree, test_setprocessed, type = "class")
Model_Accrucy = mean(prediction == test_setprocessed$Revenue)
cat("\nAccuracy of the Model\n")
Model_Accrucy
confusion_Matrix <- table(prediction, test_setprocessed$Revenue)
cat("\nEvaluation of the Model\n")
confusion_Matrix




